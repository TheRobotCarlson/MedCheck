'use strict';

// Audio Source - AWS Podcast : https://aws.amazon.com/podcasts/aws-podcast/
var audioData = [
    {
        'title' : 'sun',
        'url' : 'https://my.mixtape.moe/lgbxjo.mp3'
    }
];

module.exports = audioData;