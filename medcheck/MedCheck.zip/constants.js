"use strict";

module.exports = Object.freeze({
    
    // App-ID. TODO: set to your own Skill App ID from the developer portal.
    appId : 'amzn1.ask.skill.6fabd97e-f0ca-416d-b57f-da364549b5aa',
	avsId : 'amzn1.application.96fe405c3a9a47d3bf09ab29aad0c2f8',
	clientId : 'amzn1.application-oa2-client.15dde1feb98a45e2a925e7aec6602292',
	clientSecret : '23ecb51df435e1d3f579f8e64fded797a95e23d492246d14de200e82694fb3c1',
	
	// firebase stuff
    apiKey: "AIzaSyCp6PVbrX8EX9a1-3JhmRcIxDiDiPCqyPY",
    authDomain: "medcheck-34916.firebaseapp.com",
    databaseURL: "https://medcheck-34916.firebaseio.com",
    storageBucket: "medcheck-34916.appspot.com",
    messagingSenderId: "226005612199",

    
});
